package com.company;

public class Student {
    String name;
    String surname;
    int marks;

    public Student(String name, String surname, int marks) {
        this.name = name;
        this.surname = surname;
        this.marks = marks;
    }
}